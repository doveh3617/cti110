miles_per_gallon = float(input())
gas = float(input())
your_value1 = 20
your_value2 = 75
your_value3 = 500
print(f'{your_value1*gas/miles_per_gallon:.2f} {your_value2*gas/miles_per_gallon:.2f} {your_value3*gas/miles_per_gallon:.2f}')
