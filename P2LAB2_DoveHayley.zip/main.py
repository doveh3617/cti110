num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())
my_nums = [num1, num2, num3, num4] 


print(f'{num1 * num2 * num3 * num4:.0f} {sum(my_nums) / 4:.0f}')
print(f'{num1 * num2 * num3 * num4:.3f} {sum(my_nums) / 4:.3f}')